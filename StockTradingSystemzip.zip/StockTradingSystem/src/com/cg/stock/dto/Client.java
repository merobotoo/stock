package com.cg.stock.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="stock_master")
public class Client
{

	@Id
	@Column(name="stock_code")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int stockCode;
	private String stock;
	private double quote;
	public int getStockCode() {
		return stockCode;
	}
	public void setStockCode(int stockCode) {
		this.stockCode = stockCode;
	}
	public String getStock() {
		return stock;
	}
	public void setStock(String stock) {
		this.stock = stock;
	}
	public double getQuote() {
		return quote;
	}
	public void setQuote(double quote) {
		this.quote = quote;
	}
	public Client(int stockCode, String stock, double quote) {
		super();
		this.stockCode = stockCode;
		this.stock = stock;
		this.quote = quote;
	}
	public Client() {
		super();
	}
	@Override
	public String toString() {
		return "Client [stockCode=" + stockCode + ", stock=" + stock
				+ ", quote=" + quote + "]";
	}
	
}

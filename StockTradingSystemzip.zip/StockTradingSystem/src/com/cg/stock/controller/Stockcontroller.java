package com.cg.stock.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.stock.dto.Client;
import com.cg.stock.service.StockService;



@Controller
public class Stockcontroller
{
	@Autowired
	StockService service;			//reference variable of service interface	

	public StockService getService() {
		return service;
	}

	public void setService(StockService service) {
		this.service = service;
	}
	@RequestMapping("getstocklist")
	public String showStockList(Model model)					//whatever data i want to be displayed on jsp page
	{
		System.out.println("stock");
		List<Client> list = service.getAllStock(); 			//fetch data from database
		model.addAttribute("list",list);
		return "index";
	}
}
